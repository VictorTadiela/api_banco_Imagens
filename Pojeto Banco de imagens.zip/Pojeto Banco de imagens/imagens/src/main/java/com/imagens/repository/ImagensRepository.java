package com.imagens.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.imagens.model.ImagensModel;



@Repository
public interface ImagensRepository extends JpaRepository<ImagensModel, Long> {

}
